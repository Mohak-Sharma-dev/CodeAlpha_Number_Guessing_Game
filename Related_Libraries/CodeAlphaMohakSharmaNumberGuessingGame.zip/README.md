*Number_Guessing_Game*

This repository is a part of CodeAlpha's internship program form Jan 15th 2025 to Feb 15th 2025.

Using Random number generation, computer generates a number between 1 and 100.

Make your guess. If the difference between guess and number is greater than 10, Computer handles by prompting "That's too high" OR "That's too low"

